package util

abstract class Numbers {


}