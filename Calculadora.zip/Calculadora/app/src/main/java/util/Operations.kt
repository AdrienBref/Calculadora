package utils

fun resolverOperacion(listaOperacion : ArrayList<String>) : String {

    val operando1: Double = listaOperacion[0].toDouble()
    val operando2: Double = listaOperacion[2].toDouble()
    val operador = listaOperacion[1]
    var resultado: Double = 0.0

    when (operador) {
        "+" -> resultado = operando1 + operando2
        "-" -> resultado = operando1 - operando2
        "*" -> resultado = operando1 * operando2
        "/" -> {
            if (operando2 != 0.0) {
                resultado = operando1 / operando2
            } else {
                throw ArithmeticException("División por cero")
            }
        }
        // TODO: Falta por hacer el porcentaje
    }

    // Formatear el resultado según tus especificaciones
    val formattedResult = if (resultado % 1.0 == 0.0) {
        resultado.toInt().toString() // Si es un número entero, quitar los decimales
    } else {
        resultado.toString() // Si tiene decimales, mantenerlos
    }

    return formattedResult
}

fun evaluaSimbolo(simbolo:String):Boolean {

    return when (simbolo) {
        "+","-","*","/" -> true
        else -> false
    }
}

fun resOperacion(listaOperacion : ArrayList<String>) : String {

    val boundNum : Int = listaOperacion.size
    var resultadoString : String = ""
    var operando1: Double = listaOperacion[0].toDouble()
    var operando2: Double = 0.0
    var operador = listaOperacion[1]
    var resultado: Double = 0.0

    when(boundNum) {
        2 -> {
            operando1 = listaOperacion[0].toDouble()
            when(operador) {
                "%" -> resultado
                "sin" -> resultado
                "cos" -> resultado
                "tan" -> resultado
            }
        }
        3 -> {
            operando2 = listaOperacion[2].toDouble()

            when(operador) {
                "+" -> resultado = operando1 + operando2
                "-" -> resultado = operando1 - operando2
                "*" -> resultado = operando1 * operando2
                "/" -> {
                    if (operando2 != 0.0) {
                        resultado = operando1 / operando2
                    } else {
                        throw ArithmeticException("División por cero")
                    }
                }
            }
        }
    }

    resultadoString = conversorDec(resultado)

    return resultadoString

}

fun conversorDec(numeroResultado : Double) : String {

    val formattedResult = if (numeroResultado % 1.0 == 0.0) {
        numeroResultado.toInt().toString() // Si es un número entero, quitar los decimales
    } else {
        numeroResultado.toString() // Si tiene decimales, mantenerlos
    }

    return formattedResult

}

